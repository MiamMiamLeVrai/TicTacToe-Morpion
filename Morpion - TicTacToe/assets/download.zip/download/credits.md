# Crédits (à mettre pour le `<footer>`)

## Sites et logiciels utilisés pour les assets du site

### Sites utilisés

- [https://www.freeconvert.com](Freeconvert.com) : Convertisseur de format d'image *Dans ce cas précis du PNG -> SVG*
- [https://favicon.io](Favicon.io) : Convertisseur d'image favicons et autres + générateur du fichier `site.manifest`
- [https://coolors.co/?home](Coolors.co) : Mélangeur aléatoire de couleur
- [https://fonts.google.com](Fonts.google.com) : Librairie de police *Police utilisée : `Outfit`*
- [https://fontsource.org/tools/converter](Fontsource.com) : Convertisseur de format de police

### Logiciels utilisés (et son cas d'utilisation)

- Canva *Création de toutes les images, logo et du fond d'écran du site Le Morpion*
- Prepros *Compilateur de fichier SASS/SCSS en CSS, visualiseur des sites webs en local*

#### Droits et utilisations des assets

M
